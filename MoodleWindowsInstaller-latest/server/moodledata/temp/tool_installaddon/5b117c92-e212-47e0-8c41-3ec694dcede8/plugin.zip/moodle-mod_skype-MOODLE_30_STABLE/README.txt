Skype Activit Module for Moodle 2.x
Documentation: http://docs.moodle.org/22/en/Skype_module
Support: http://3mro.wordpress.com/amr-hourani-moodle-support/
Amr Hourani